---
name: Native Android build environment
description: The workspace can run Java and Gradle but does not include an Android SDK by default.
---

Native Android modules should be opened in Android Studio or built in an environment with `ANDROID_HOME`/`ANDROID_SDK_ROOT` configured and Android SDK Platform 35 installed.

**Why:** Gradle configuration and wrapper tasks succeed here, but APK compilation stops before source compilation when the Android SDK is absent.

**How to apply:** Treat Gradle task configuration and pure Kotlin/parser checks as locally verifiable; document the SDK prerequisite instead of claiming an APK build succeeded.