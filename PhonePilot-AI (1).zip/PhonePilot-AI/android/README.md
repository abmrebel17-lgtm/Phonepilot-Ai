# PhonePilot AI

PhonePilot AI is a native Android V1 voice/text assistant for safe actions on the
user's own phone. It uses Kotlin, Jetpack Compose, and standard Android APIs.
The command engine is local in V1 so it works without an AI API key or a server.

## Project structure

- `app/src/main/java/com/phonepilot/ai/engine` — natural-language command parser.
- `app/src/main/java/com/phonepilot/ai/actions` — one Android action/tool per intent.
- `app/src/main/java/com/phonepilot/ai/model` — parser, action, permission, confirmation,
  and history contracts.
- `app/src/main/java/com/phonepilot/ai/PhonePilotViewModel.kt` — orchestration, safety
  confirmation, runtime permission flow, and local history.
- `app/src/main/java/com/phonepilot/ai/MainActivity.kt` — Compose home, settings,
  permissions, history, voice input, and confirmation dialogs.

The `PhoneAction` interface and `ActionRegistry` are the extension point for future
tools. Understanding a command is separate from executing it.

## Requirements

- Android Studio Ladybug or newer.
- Android SDK Platform 35 and Build Tools installed.
- JDK 17.
- A real Android phone or an Android emulator running API 26 or higher.

## Open and run

1. Open the `android` directory in Android Studio.
2. Let Android Studio sync Gradle and install any missing SDK components.
3. Connect an Android phone with Developer options and USB debugging enabled, or
   start an emulator.
4. Run the `app` configuration.
5. Grant permissions only when a feature needs them. The dedicated Permissions
   screen explains every permission.

From a terminal with the Android SDK configured:

```bash
cd android
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

The included wrapper uses Gradle 8.9, so a separate Gradle installation is not
needed.

## Build the APK using only an Android phone

The repository includes `.github/workflows/build-android.yml`, which builds the
debug APK on GitHub's hosted Android/Java environment. This avoids needing a
computer or Android Studio.

1. From the Replit mobile interface, connect or push this project to a GitHub
   repository.
2. Open that repository in a mobile browser.
3. Open **Actions**, select **Build PhonePilot AI APK**, and tap **Run workflow**.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact named
   `phonepilot-ai-debug-apk`.
6. Extract the downloaded ZIP on your phone and tap `app-debug.apk`.
7. If Android blocks the install, allow your browser or file manager to install
   unknown apps, then retry. This permission is controlled by Android, not
   PhonePilot.

The workflow is also triggered automatically when files under `android/` change.

## V1 commands

The local parser accepts natural variations of:

- `Call John` / `Could you call Mom`
- `Open YouTube` / `Launch WhatsApp`
- `Turn on flashlight` / `Switch off torch`
- `Increase volume` / `Set volume to 50 percent`
- `Set an alarm for 7 AM tomorrow`
- `Take a screenshot`
- `Search the web for weather in Srinagar`

## Android limitations handled honestly

- Calls resolve a contact and number, then require confirmation before using
  `ACTION_CALL`. No call is made silently.
- Alarms require confirmation and then open Android's supported `ACTION_SET_ALARM`
  flow. The Clock app remains responsible for creating the alarm.
- Android does not permit a normal app to take a silent screenshot. PhonePilot
  reports that limitation and points the user to Power + Volume Down or Quick
  Settings instead of pretending it succeeded.
- Flashlight control uses `CameraManager.setTorchMode`; it requests camera
  permission only when the flashlight action is used and does not capture images.
- Web search opens the browser with an encoded query. No network permission is
  requested by PhonePilot.

## Real-device validation record (September 19, 2026)

The real-phone pass is **not completed in this workspace**. This environment
does not expose a physical Android device, `adb`, or an Android SDK, so an APK
could not be built or installed here. `./gradlew testDebugUnitTest` and
`./gradlew assembleDebug` both stop before compilation with an Android SDK
location error. No install or runtime result is claimed from this environment.

When a phone is available, record the phone model, Android version, default
browser, dialer, and Clock app, then run this matrix:

| Check | Expected result |
| --- | --- |
| Install and launch the debug APK | Installs successfully and opens the PhonePilot home screen. |
| Deny microphone permission, then tap Speak | A clear denial message appears and voice input stays off. |
| Deny Contacts permission, then submit a call | The call does not proceed and the history entry is failed. |
| Allow Contacts, use a single matching contact, then cancel | The contact and number appear in confirmation; cancelling makes no call and records **Cancelled**. |
| Confirm a call with Phone permission denied | Android denial is reported and no call is placed. |
| Allow Phone permission and confirm a call | The device's dialer/call service starts for the resolved number. Verify carrier/SIM behavior separately. |
| Open an installed app and an unknown app | The installed app launches; the unknown app reports a clear failure. |
| Deny Camera permission, then use the flashlight | The action does not change the torch and reports that permission was not granted. |
| Allow Camera permission; turn flashlight on and off | The hardware torch changes state and each result is reported. |
| Increase, decrease, and set media volume | Android's media-volume UI/value changes and the result reports the new percentage. |
| Cancel an alarm confirmation | No Clock handoff occurs and history records **Cancelled**. |
| Confirm an alarm | The installed Clock app opens through `ACTION_SET_ALARM`; verify its displayed time and whether the user must save it. |
| Take a screenshot | A clear Android limitation is shown; PhonePilot does not pretend to have created a screenshot. |
| Search the web | The default browser opens an encoded search for the requested text. |

Document any phone-specific differences in the test report, especially missing
or non-default dialer/Clock/browser handlers, no camera torch, denied
permissions, lack of a SIM, and behavior of the system speech recognizer.

## Permissions

- `RECORD_AUDIO` — system speech recognition after tapping Speak.
- `READ_CONTACTS` — resolving a named contact for a call.
- `CALL_PHONE` — placing a call after the user confirms.
- `CAMERA` — Android flashlight/torch API only.

PhonePilot V1 does not request SMS, location, internet, accessibility,
notifications, background microphone, or broad storage permissions.