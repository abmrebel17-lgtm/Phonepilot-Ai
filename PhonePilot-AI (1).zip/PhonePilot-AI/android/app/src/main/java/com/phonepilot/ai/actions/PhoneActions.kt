package com.phonepilot.ai.actions

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.phonepilot.ai.model.ActionResult
import com.phonepilot.ai.model.AlarmSpec
import com.phonepilot.ai.model.CommandIntent
import com.phonepilot.ai.model.ParsedCommand
import com.phonepilot.ai.model.VolumeOperation
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface PhoneAction {
    suspend fun prepare(command: ParsedCommand): ActionResult
    suspend fun execute(command: ParsedCommand): ActionResult
}

class ActionRegistry(private val context: Context) {
    private val actions: Map<CommandIntent, PhoneAction> = mapOf(
        CommandIntent.CALL to CallAction(context),
        CommandIntent.OPEN_APP to OpenAppAction(context),
        CommandIntent.FLASHLIGHT to FlashlightAction(context),
        CommandIntent.VOLUME to VolumeAction(context),
        CommandIntent.SCREENSHOT to ScreenshotAction(),
        CommandIntent.ALARM to AlarmAction(context),
        CommandIntent.WEB_SEARCH to WebSearchAction(context),
    )

    fun actionFor(intent: CommandIntent): PhoneAction? = actions[intent]
}

private class CallAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult {
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            return ActionResult.NeedsPermission(
                permission = Manifest.permission.READ_CONTACTS,
                explanation = "Contacts access is only used to find the phone number for the person you named.",
            )
        }
        val target = command.target.orEmpty()
        val matches = withContext(Dispatchers.IO) { findContacts(target) }
        return when {
            matches.isEmpty() -> ActionResult.Failure(
                "I couldn't find a contact named “$target”.",
                "Check the spelling or add the person to Contacts.",
            )
            matches.size > 1 -> ActionResult.Failure(
                "I found multiple contacts named “$target”.",
                "Use a more specific name, then try again.",
            )
            else -> {
                val match = matches.first()
                ActionResult.ConfirmationRequired(
                    com.phonepilot.ai.model.Confirmation.Call(match.name, match.number),
                )
            }
        }
    }

    override suspend fun execute(command: ParsedCommand): ActionResult {
        if (!hasPermission(Manifest.permission.CALL_PHONE)) {
            return ActionResult.NeedsPermission(
                permission = Manifest.permission.CALL_PHONE,
                explanation = "Phone permission is required only after you confirm this call.",
            )
        }
        val number = command.resolvedPhoneNumber
            ?: return ActionResult.Failure("I lost the phone number before the call could start.")
        return try {
            context.startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}")))
            ActionResult.Success("Calling ${command.resolvedContactName ?: command.target ?: "contact"} at $number.")
        } catch (_: SecurityException) {
            ActionResult.Failure("Android denied the call.", "Allow phone permission in Settings and try again.")
        } catch (_: ActivityNotFoundException) {
            ActionResult.Failure("This phone does not have an app that can place calls.")
        }
    }

    private fun findContacts(target: String): List<ContactMatch> {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI
            .buildUpon()
            .appendPath(Uri.encode(target))
            .build()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
        )
        val results = mutableListOf<ContactMatch>()
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext() && results.size < 5) {
                val name = cursor.getString(nameIndex).orEmpty()
                val number = cursor.getString(numberIndex).orEmpty()
                if (number.isNotBlank() && results.none { it.number == number }) {
                    results += ContactMatch(name.ifBlank { target }, number)
                }
            }
        }
        return results
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private data class ContactMatch(val name: String, val number: String)
}

private class OpenAppAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult = ActionResult.Success("")

    override suspend fun execute(command: ParsedCommand): ActionResult {
        val target = command.target.orEmpty().lowercase(Locale.getDefault())
        if (target.isBlank()) return ActionResult.Failure("Tell me which app to open.")
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = context.packageManager.queryIntentActivities(launcherIntent, 0)
        val match = matches
            .asSequence()
            .mapNotNull { info ->
                val label = info.loadLabel(context.packageManager).toString()
                val packageName = info.activityInfo.packageName
                if (label.lowercase(Locale.getDefault()) == target ||
                    packageName.lowercase(Locale.getDefault()) == target ||
                    label.lowercase(Locale.getDefault()).contains(target)
                ) {
                    info
                } else {
                    null
                }
            }
            .firstOrNull()
            ?: return ActionResult.Failure(
                "I couldn't find an installed app matching “${command.target}”.",
                "Install the app or try its exact name.",
            )
        val launchIntent = context.packageManager.getLaunchIntentForPackage(
            match.activityInfo.packageName,
        ) ?: return ActionResult.Failure("Android did not provide a launch action for ${command.target}.")
        return try {
            context.startActivity(launchIntent)
            ActionResult.Success("${match.loadLabel(context.packageManager)} opened.")
        } catch (_: ActivityNotFoundException) {
            ActionResult.Failure("Android could not open ${command.target}.")
        }
    }
}

private class FlashlightAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult {
        return if (!hasPermission(Manifest.permission.CAMERA)) {
            ActionResult.NeedsPermission(
                permission = Manifest.permission.CAMERA,
                explanation = "Camera access is needed by Android's flashlight API. PhonePilot does not take photos.",
            )
        } else {
            ActionResult.Success("")
        }
    }

    override suspend fun execute(command: ParsedCommand): ActionResult {
        if (!hasPermission(Manifest.permission.CAMERA)) {
            return ActionResult.NeedsPermission(
                permission = Manifest.permission.CAMERA,
                explanation = "Camera access is needed by Android's flashlight API. PhonePilot does not take photos.",
            )
        }
        val desiredState = command.flashlightOn ?: true
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult.Failure("This phone does not report a usable flashlight.")
            cameraManager.setTorchMode(cameraId, desiredState)
            ActionResult.Success("Flashlight turned ${if (desiredState) "on" else "off"}.")
        } catch (_: SecurityException) {
            ActionResult.Failure("Android denied flashlight access.", "Allow camera permission and try again.")
        } catch (_: Exception) {
            ActionResult.Failure("Android could not change the flashlight state.")
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
}

private class VolumeAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult = ActionResult.Success("")

    override suspend fun execute(command: ParsedCommand): ActionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return try {
            when (command.volumeOperation) {
                VolumeOperation.INCREASE -> audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_RAISE,
                    AudioManager.FLAG_SHOW_UI,
                )
                VolumeOperation.DECREASE -> audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_LOWER,
                    AudioManager.FLAG_SHOW_UI,
                )
                VolumeOperation.SET -> {
                    val percent = command.volumePercent ?: return ActionResult.Failure("Tell me the volume percentage.")
                    audioManager.setStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        (max * percent / 100f).roundToInt().coerceIn(0, max),
                        AudioManager.FLAG_SHOW_UI,
                    )
                }
                null -> return ActionResult.Failure("Tell me whether to increase, decrease, or set the volume.")
            }
            val updated = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val displayPercent = (updated * 100f / max.coerceAtLeast(1)).roundToInt()
            val message = when (command.volumeOperation) {
                VolumeOperation.INCREASE -> "Media volume increased to $displayPercent%."
                VolumeOperation.DECREASE -> "Media volume decreased to $displayPercent%."
                VolumeOperation.SET -> "Media volume set to $displayPercent%."
                null -> "Media volume is at $displayPercent%."
            }
            ActionResult.Success(message)
        } catch (_: SecurityException) {
            ActionResult.Failure(
                "Android prevented the volume change.",
                "Use your phone's hardware volume buttons or system volume panel.",
            )
        } catch (_: Exception) {
            ActionResult.Failure("Android could not change media volume.")
        }
    }
}

private class ScreenshotAction : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult = ActionResult.Success("")

    override suspend fun execute(command: ParsedCommand): ActionResult = ActionResult.Failure(
        "Android does not allow PhonePilot to take a silent screenshot.",
        "Use your phone's Power + Volume Down buttons, or the screenshot control in Quick Settings.",
    )
}

private class AlarmAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult {
        val spec = command.alarm ?: return ActionResult.Failure("Tell me what time to set the alarm.")
        return ActionResult.ConfirmationRequired(com.phonepilot.ai.model.Confirmation.Alarm(spec))
    }

    override suspend fun execute(command: ParsedCommand): ActionResult {
        val spec = command.alarm ?: return ActionResult.Failure("Tell me what time to set the alarm.")
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, spec.hour)
            putExtra(AlarmClock.EXTRA_MINUTES, spec.minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "PhonePilot AI alarm")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (intent.resolveActivity(context.packageManager) == null) {
            ActionResult.Failure("No Clock app on this phone accepted Android's alarm intent.")
        } else {
            try {
                context.startActivity(intent)
                ActionResult.Success(
                    "Alarm setup opened in your Clock app for ${spec.displayTime()}.",
                )
            } catch (_: ActivityNotFoundException) {
                ActionResult.Failure("Android could not open the Clock app.")
            }
        }
    }
}

private class WebSearchAction(private val context: Context) : PhoneAction {
    override suspend fun prepare(command: ParsedCommand): ActionResult = ActionResult.Success("")

    override suspend fun execute(command: ParsedCommand): ActionResult {
        val query = command.searchQuery.orEmpty()
        if (query.isBlank()) return ActionResult.Failure("Tell me what to search for.")
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=${Uri.encode(query)}"),
        )
        return if (intent.resolveActivity(context.packageManager) == null) {
            ActionResult.Failure("No browser is available for web search.")
        } else {
            try {
                context.startActivity(intent)
                ActionResult.Success("Opened a web search for “$query”.")
            } catch (_: ActivityNotFoundException) {
                ActionResult.Failure("Android could not open the browser.")
            }
        }
    }
}