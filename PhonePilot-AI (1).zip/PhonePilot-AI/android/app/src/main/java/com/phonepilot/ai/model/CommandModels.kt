package com.phonepilot.ai.model

import android.Manifest

enum class CommandIntent {
    CALL,
    OPEN_APP,
    FLASHLIGHT,
    VOLUME,
    SCREENSHOT,
    ALARM,
    WEB_SEARCH,
}

enum class HistoryStatus {
    SUCCESS,
    FAILED,
    CANCELLED,
}

enum class VolumeOperation {
    INCREASE,
    DECREASE,
    SET,
}

data class AlarmSpec(
    val hour: Int,
    val minute: Int,
    val tomorrowRequested: Boolean,
) {
    fun displayTime(): String {
        val suffix = if (hour >= 12) "PM" else "AM"
        val displayHour = when (val value = hour % 12) {
            0 -> 12
            else -> value
        }
        return "%d:%02d %s".format(displayHour, minute, suffix)
    }
}

data class ParsedCommand(
    val raw: String,
    val intent: CommandIntent,
    val target: String? = null,
    val flashlightOn: Boolean? = null,
    val volumeOperation: VolumeOperation? = null,
    val volumePercent: Int? = null,
    val alarm: AlarmSpec? = null,
    val searchQuery: String? = null,
    val resolvedPhoneNumber: String? = null,
    val resolvedContactName: String? = null,
)

sealed interface Confirmation {
    data class Call(
        val contactName: String,
        val phoneNumber: String,
    ) : Confirmation

    data class Alarm(
        val spec: AlarmSpec,
    ) : Confirmation
}

sealed interface ActionResult {
    data class Success(val message: String) : ActionResult
    data class Failure(val message: String, val nextStep: String? = null) : ActionResult
    data class NeedsPermission(
        val permission: String,
        val explanation: String,
    ) : ActionResult

    data class ConfirmationRequired(val confirmation: Confirmation) : ActionResult
}

data class HistoryEntry(
    val command: String,
    val status: HistoryStatus,
    val timestamp: Long,
)

data class PendingConfirmation(
    val command: ParsedCommand,
    val confirmation: Confirmation,
)

data class PermissionRequest(
    val id: Long,
    val permission: String,
    val explanation: String,
)

data class UserMessage(
    val id: Long,
    val text: String,
)

data class AppUiState(
    val history: List<HistoryEntry> = emptyList(),
    val pendingConfirmation: PendingConfirmation? = null,
    val permissionRequest: PermissionRequest? = null,
    val message: UserMessage? = null,
    val lastRecognizedCommand: String? = null,
)

fun permissionLabel(permission: String): String = when (permission) {
    Manifest.permission.RECORD_AUDIO -> "Microphone"
    Manifest.permission.READ_CONTACTS -> "Contacts"
    Manifest.permission.CALL_PHONE -> "Phone calls"
    Manifest.permission.CAMERA -> "Camera / flashlight"
    else -> permission
}