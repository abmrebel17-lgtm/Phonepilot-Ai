package com.phonepilot.ai.data

import android.content.Context
import com.phonepilot.ai.model.HistoryEntry
import com.phonepilot.ai.model.HistoryStatus
import org.json.JSONArray
import org.json.JSONObject

class HistoryStore(context: Context) {
    private val preferences = context.getSharedPreferences("phonepilot_history", Context.MODE_PRIVATE)
    private val key = "entries"

    fun load(): List<HistoryEntry> {
        val raw = preferences.getString(key, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.getJSONObject(index)
                    add(
                        HistoryEntry(
                            command = item.getString("command"),
                            status = HistoryStatus.valueOf(item.getString("status")),
                            timestamp = item.getLong("timestamp"),
                        ),
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun save(entries: List<HistoryEntry>) {
        val array = JSONArray()
        entries.take(20).forEach { entry ->
            array.put(
                JSONObject().apply {
                    put("command", entry.command)
                    put("status", entry.status.name)
                    put("timestamp", entry.timestamp)
                },
            )
        }
        preferences.edit().putString(key, array.toString()).apply()
    }

    fun clear() {
        preferences.edit().remove(key).apply()
    }
}