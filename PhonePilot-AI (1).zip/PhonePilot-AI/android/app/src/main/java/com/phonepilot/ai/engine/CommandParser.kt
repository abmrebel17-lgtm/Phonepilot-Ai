package com.phonepilot.ai.engine

import com.phonepilot.ai.model.AlarmSpec
import com.phonepilot.ai.model.CommandIntent
import com.phonepilot.ai.model.ParsedCommand
import com.phonepilot.ai.model.VolumeOperation

sealed interface ParseResult {
    data class Parsed(val command: ParsedCommand) : ParseResult
    data class Unknown(val message: String) : ParseResult
}

class LocalCommandParser {
    private val timePattern = Regex(
        pattern = """(?i)\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b""",
    )

    fun parse(rawInput: String): ParseResult {
        val raw = rawInput.trim()
        val input = raw.lowercase().replace(Regex("\\s+"), " ")
        if (input.isBlank()) {
            return ParseResult.Unknown("Type or say a command first.")
        }

        parseCall(input, raw)?.let { return ParseResult.Parsed(it) }
        parseFlashlight(input, raw)?.let { return ParseResult.Parsed(it) }
        parseVolume(input, raw)?.let { return ParseResult.Parsed(it) }
        parseScreenshot(input, raw)?.let { return ParseResult.Parsed(it) }
        parseAlarm(input, raw)?.let { return ParseResult.Parsed(it) }
        parseSearch(input, raw)?.let { return ParseResult.Parsed(it) }
        parseOpenApp(input, raw)?.let { return ParseResult.Parsed(it) }

        return ParseResult.Unknown(
            "I don't recognize that yet. Try “open YouTube”, “turn on flashlight”, or “search the web for weather”.",
        )
    }

    private fun parseCall(input: String, raw: String): ParsedCommand? {
        val match = Regex(
            """^(?:hey\s+)?(?:can you\s+|could you\s+|please\s+)?(?:call|phone|dial|ring)\s+(.+)$""",
        ).find(input) ?: return null
        val target = cleanTarget(match.groupValues[1])
        if (target.isBlank()) return null
        return ParsedCommand(raw = raw, intent = CommandIntent.CALL, target = target)
    }

    private fun parseOpenApp(input: String, raw: String): ParsedCommand? {
        val match = Regex(
            """^(?:hey\s+)?(?:can you\s+|could you\s+|please\s+)?(?:open|launch|start|run)\s+(?:the\s+)?(.+)$""",
        ).find(input) ?: return null
        val target = cleanTarget(match.groupValues[1])
        if (target.isBlank()) return null
        return ParsedCommand(raw = raw, intent = CommandIntent.OPEN_APP, target = target)
    }

    private fun parseFlashlight(input: String, raw: String): ParsedCommand? {
        if (!Regex("""\b(flashlight|torch)\b""").containsMatchIn(input)) return null
        val turnOn = when {
            Regex("""\b(turn|switch|power)\s+on\b|\bon\b""").containsMatchIn(input) -> true
            Regex("""\b(turn|switch|power)\s+off\b|\boff\b""").containsMatchIn(input) -> false
            else -> true
        }
        return ParsedCommand(
            raw = raw,
            intent = CommandIntent.FLASHLIGHT,
            flashlightOn = turnOn,
        )
    }

    private fun parseVolume(input: String, raw: String): ParsedCommand? {
        if (!input.contains("volume") && !input.contains("sound")) return null
        val setMatch = Regex(
            """set\s+(?:the\s+)?(?:media\s+)?volume\s+to\s+(\d{1,3})(?:\s*%|\s*percent)?""",
        ).find(input)
        if (setMatch != null) {
            val percent = setMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100) ?: return null
            return ParsedCommand(
                raw = raw,
                intent = CommandIntent.VOLUME,
                volumeOperation = VolumeOperation.SET,
                volumePercent = percent,
            )
        }
        val operation = when {
            Regex("""\b(increase|raise|turn up|louder|up)\b""").containsMatchIn(input) ->
                VolumeOperation.INCREASE
            Regex("""\b(decrease|lower|turn down|quieter|down)\b""").containsMatchIn(input) ->
                VolumeOperation.DECREASE
            else -> null
        } ?: return null
        return ParsedCommand(raw = raw, intent = CommandIntent.VOLUME, volumeOperation = operation)
    }

    private fun parseScreenshot(input: String, raw: String): ParsedCommand? {
        if (!Regex("""\b(screenshot|screen shot|capture my screen|capture the screen)\b""")
                .containsMatchIn(input)
        ) {
            return null
        }
        return ParsedCommand(raw = raw, intent = CommandIntent.SCREENSHOT)
    }

    private fun parseAlarm(input: String, raw: String): ParsedCommand? {
        if (!input.contains("alarm") && !input.contains("wake me")) return null
        val timeMatch = timePattern.find(input) ?: return null
        val hourInput = timeMatch.groupValues[1].toIntOrNull() ?: return null
        val minute = timeMatch.groupValues[2].ifBlank { "0" }.toIntOrNull() ?: return null
        if (hourInput !in 0..23 || minute !in 0..59) return null
        val meridiem = timeMatch.groupValues[3].lowercase()
        val hour = when {
            meridiem == "pm" && hourInput in 1..11 -> hourInput + 12
            meridiem == "am" && hourInput == 12 -> 0
            meridiem.isBlank() -> hourInput
            else -> hourInput
        }
        if (hour !in 0..23) return null
        return ParsedCommand(
            raw = raw,
            intent = CommandIntent.ALARM,
            alarm = AlarmSpec(
                hour = hour,
                minute = minute,
                tomorrowRequested = input.contains("tomorrow"),
            ),
        )
    }

    private fun parseSearch(input: String, raw: String): ParsedCommand? {
        val match = Regex(
            """^(?:hey\s+)?(?:can you\s+|could you\s+|please\s+)?(?:search|google|look up)(?:\s+the\s+web)?(?:\s+for)?\s+(.+)$""",
        ).find(input) ?: return null
        val query = cleanTarget(match.groupValues[1])
        if (query.isBlank()) return null
        return ParsedCommand(raw = raw, intent = CommandIntent.WEB_SEARCH, searchQuery = query)
    }

    private fun cleanTarget(value: String): String = value
        .replace(Regex("""\b(for me|please|the app)\b"""), "")
        .trim()
        .trim('.', ',', '?', '!')
}