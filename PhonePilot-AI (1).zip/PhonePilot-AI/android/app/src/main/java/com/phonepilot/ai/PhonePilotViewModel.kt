package com.phonepilot.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.phonepilot.ai.actions.ActionRegistry
import com.phonepilot.ai.data.HistoryStore
import com.phonepilot.ai.engine.CommandParser
import com.phonepilot.ai.engine.ParseResult
import com.phonepilot.ai.model.ActionResult
import com.phonepilot.ai.model.AppUiState
import com.phonepilot.ai.model.Confirmation
import com.phonepilot.ai.model.HistoryEntry
import com.phonepilot.ai.model.HistoryStatus
import com.phonepilot.ai.model.ParsedCommand
import com.phonepilot.ai.model.PendingConfirmation
import com.phonepilot.ai.model.PermissionRequest
import com.phonepilot.ai.model.UserMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PhonePilotViewModel(application: Application) : AndroidViewModel(application) {
    private val parser = CommandParser()
    private val actionRegistry = ActionRegistry(application)
    private val historyStore = HistoryStore(application)
    private val _uiState = MutableStateFlow(AppUiState(history = historyStore.load()))
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var pendingCommand: ParsedCommand? = null
    private var requestId = 0L
    private var messageId = 0L

    fun submitCommand(raw: String) {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) {
            showMessage("Type or say a command first.")
            return
        }
        viewModelScope.launch {
            when (val result = parser.parse(trimmed)) {
                is ParseResult.Unknown -> {
                    record(trimmed, HistoryStatus.FAILED)
                    showMessage(result.message)
                }
                is ParseResult.Parsed -> prepare(result.command)
            }
        }
    }

    fun setLastRecognizedCommand(command: String) {
        _uiState.value = _uiState.value.copy(lastRecognizedCommand = command)
    }

    fun confirmPending() {
        val pending = _uiState.value.pendingConfirmation ?: return
        val executable = when (val confirmation = pending.confirmation) {
            is Confirmation.Call -> pending.command.copy(
                resolvedPhoneNumber = confirmation.phoneNumber,
                resolvedContactName = confirmation.contactName,
            )
            is Confirmation.Alarm -> pending.command
        }
        viewModelScope.launch {
            when (val result = actionRegistry.actionFor(executable.intent)?.execute(executable)) {
                null -> finishFailure(pending.command.raw, "That action is not available.")
                is ActionResult.NeedsPermission -> requestPermissionForConfirmation(result)
                is ActionResult.Success -> {
                    clearConfirmation()
                    finishSuccess(pending.command.raw, result.message)
                }
                is ActionResult.Failure -> {
                    clearConfirmation()
                    finishFailure(pending.command.raw, result.message, result.nextStep)
                }
                is ActionResult.ConfirmationRequired -> Unit
            }
        }
    }

    fun cancelPending() {
        val pending = _uiState.value.pendingConfirmation ?: return
        clearConfirmation()
        record(pending.command.raw, HistoryStatus.CANCELLED)
        showMessage("Cancelled. No action was taken.")
    }

    fun onPermissionResult(granted: Boolean) {
        val request = _uiState.value.permissionRequest ?: return
        _uiState.value = _uiState.value.copy(permissionRequest = null)
        if (!granted) {
            val confirmationWasPending = _uiState.value.pendingConfirmation != null
            val command = _uiState.value.pendingConfirmation?.command ?: pendingCommand
            pendingCommand = null
            if (confirmationWasPending) clearConfirmation()
            if (command != null) {
                record(command.raw, HistoryStatus.FAILED)
            }
            showMessage("${request.explanation} Permission was not granted.")
            return
        }
        if (_uiState.value.pendingConfirmation != null) {
            confirmPending()
        } else {
            val command = pendingCommand
            pendingCommand = null
            if (command != null) viewModelScope.launch { prepare(command) }
        }
    }

    fun clearMessage() {
        _uiState.value = _uiState.value.copy(message = null)
    }

    fun clearHistory() {
        historyStore.clear()
        _uiState.value = _uiState.value.copy(history = emptyList())
        showMessage("Command history cleared.")
    }

    fun showMessage(message: String) {
        messageId += 1
        _uiState.value = _uiState.value.copy(message = UserMessage(messageId, message))
    }

    private suspend fun prepare(command: ParsedCommand) {
        val action = actionRegistry.actionFor(command.intent)
        if (action == null) {
            finishFailure(command.raw, "That action is not available.")
            return
        }
        when (val result = action.prepare(command)) {
            is ActionResult.NeedsPermission -> {
                pendingCommand = command
                requestPermission(result)
            }
            is ActionResult.ConfirmationRequired -> {
                _uiState.value = _uiState.value.copy(
                    pendingConfirmation = PendingConfirmation(command, result.confirmation),
                )
            }
            is ActionResult.Success -> execute(command)
            is ActionResult.Failure -> finishFailure(command.raw, result.message, result.nextStep)
        }
    }

    private suspend fun execute(command: ParsedCommand) {
        when (val result = actionRegistry.actionFor(command.intent)?.execute(command)) {
            null -> finishFailure(command.raw, "That action is not available.")
            is ActionResult.Success -> finishSuccess(command.raw, result.message)
            is ActionResult.Failure -> finishFailure(command.raw, result.message, result.nextStep)
            is ActionResult.NeedsPermission -> {
                pendingCommand = command
                requestPermission(result)
            }
            is ActionResult.ConfirmationRequired -> Unit
        }
    }

    private fun requestPermission(result: ActionResult.NeedsPermission) {
        requestId += 1
        _uiState.value = _uiState.value.copy(
            permissionRequest = PermissionRequest(requestId, result.permission, result.explanation),
        )
    }

    private fun requestPermissionForConfirmation(result: ActionResult.NeedsPermission) {
        requestId += 1
        _uiState.value = _uiState.value.copy(
            permissionRequest = PermissionRequest(requestId, result.permission, result.explanation),
        )
    }

    private fun clearConfirmation() {
        _uiState.value = _uiState.value.copy(pendingConfirmation = null)
    }

    private fun finishSuccess(raw: String, message: String) {
        record(raw, HistoryStatus.SUCCESS)
        showMessage(message)
    }

    private fun finishFailure(raw: String, message: String, nextStep: String? = null) {
        record(raw, HistoryStatus.FAILED)
        showMessage(if (nextStep == null) message else "$message $nextStep")
    }

    private fun record(command: String, status: HistoryStatus) {
        val updated = listOf(HistoryEntry(command, status, System.currentTimeMillis())) +
            _uiState.value.history
        val trimmed = updated.take(20)
        historyStore.save(trimmed)
        _uiState.value = _uiState.value.copy(history = trimmed)
    }
}