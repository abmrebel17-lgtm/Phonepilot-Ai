package com.phonepilot.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFF4C5DFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE1E5FF),
    onPrimaryContainer = Color(0xFF0D185F),
    secondary = Color(0xFF58627A),
    secondaryContainer = Color(0xFFE0E4F5),
    background = Color(0xFFF8F9FF),
    surface = Color(0xFFF8F9FF),
    surfaceVariant = Color(0xFFE4E5F0),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFBAC2FF),
    onPrimary = Color(0xFF152477),
    primaryContainer = Color(0xFF303F91),
    onPrimaryContainer = Color(0xFFE1E5FF),
    secondary = Color(0xFFC0C7DF),
    secondaryContainer = Color(0xFF41485E),
    background = Color(0xFF111318),
    surface = Color(0xFF111318),
    surfaceVariant = Color(0xFF45464F),
)

@Composable
fun PhonePilotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        content = content,
    )
}