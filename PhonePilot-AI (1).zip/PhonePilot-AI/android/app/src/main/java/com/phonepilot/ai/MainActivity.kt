package com.phonepilot.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Cancel
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Screenshot
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.phonepilot.ai.model.AppUiState
import com.phonepilot.ai.model.Confirmation
import com.phonepilot.ai.model.HistoryEntry
import com.phonepilot.ai.model.HistoryStatus
import com.phonepilot.ai.model.PermissionRequest
import com.phonepilot.ai.model.permissionLabel
import com.phonepilot.ai.ui.theme.PhonePilotTheme

class MainActivity : ComponentActivity() {
    private val viewModel by viewModels<PhonePilotViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PhonePilotTheme {
                PhonePilotApp(viewModel)
            }
        }
    }
}

private enum class AppScreen {
    HOME,
    SETTINGS,
    PERMISSIONS,
}

@Composable
private fun PhonePilotApp(viewModel: PhonePilotViewModel) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var screen by rememberSaveable { mutableStateOf(AppScreen.HOME) }
    var commandText by rememberSaveable { mutableStateOf("") }
    var permissionRefresh by remember { mutableIntStateOf(0) }
    var manualPermission by remember { mutableStateOf<String?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        val recognized = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (recognized.isNullOrBlank()) {
            viewModel.showMessage("I couldn't recognize a command.")
        } else {
            commandText = recognized
            viewModel.setLastRecognizedCommand(recognized)
            viewModel.submitCommand(recognized)
        }
    }

    val startVoice: () -> Unit = {
        runCatching {
            voiceLauncher.launch(speechIntent())
        }.onFailure {
            viewModel.showMessage("No Android speech recognition app is available on this phone.")
        }
    }

    val microphonePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        if (granted) {
            startVoice()
        } else {
            viewModel.showMessage("Microphone permission was not granted. Voice input remains off.")
        }
    }

    val commandPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> viewModel.onPermissionResult(granted) }

    val manualPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) {
        manualPermission = null
        permissionRefresh += 1
    }

    LaunchedEffect(state.permissionRequest?.id) {
        state.permissionRequest?.let { request ->
            commandPermissionLauncher.launch(request.permission)
        }
    }

    LaunchedEffect(state.message?.id) {
        state.message?.let { message ->
            snackbarHostState.showSnackbar(message.text)
            viewModel.clearMessage()
        }
    }

    BackHandler(enabled = screen != AppScreen.HOME) {
        screen = if (screen == AppScreen.PERMISSIONS) AppScreen.SETTINGS else AppScreen.HOME
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        when (screen) {
            AppScreen.HOME -> HomeScreen(
                state = state,
                commandText = commandText,
                onCommandTextChange = { commandText = it },
                onSubmit = {
                    viewModel.submitCommand(commandText)
                    commandText = ""
                },
                onSpeak = {
                    if (ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO,
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        startVoice()
                    } else {
                        microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                },
                onQuickAction = { command, prefill ->
                    if (prefill != null) {
                        commandText = prefill
                    } else {
                        viewModel.submitCommand(command)
                    }
                },
                onSettings = { screen = AppScreen.SETTINGS },
                onClearHistory = viewModel::clearHistory,
                modifier = Modifier.padding(padding),
            )
            AppScreen.SETTINGS -> SettingsScreen(
                onBack = { screen = AppScreen.HOME },
                onPermissions = { screen = AppScreen.PERMISSIONS },
                modifier = Modifier.padding(padding),
            )
            AppScreen.PERMISSIONS -> PermissionsScreen(
                refreshKey = permissionRefresh,
                onBack = { screen = AppScreen.SETTINGS },
                onRequest = { permission ->
                    manualPermission = permission
                    manualPermissionLauncher.launch(permission)
                },
                modifier = Modifier.padding(padding),
            )
        }
    }

    state.pendingConfirmation?.let { pending ->
        ConfirmationDialog(
            confirmation = pending.confirmation,
            onConfirm = viewModel::confirmPending,
            onCancel = viewModel::cancelPending,
        )
    }
}

@Composable
private fun HomeScreen(
    state: AppUiState,
    commandText: String,
    onCommandTextChange: (String) -> Unit,
    onSubmit: () -> Unit,
    onSpeak: () -> Unit,
    onQuickAction: (String, String?) -> Unit,
    onSettings: () -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val quickActions = listOf(
        QuickAction("Call", Icons.Outlined.Call, null, "Call "),
        QuickAction("Open App", Icons.Outlined.Apps, null, "Open "),
        QuickAction("Flashlight", Icons.Outlined.FlashOn, "Turn on flashlight", null),
        QuickAction("Volume", Icons.Outlined.VolumeUp, "Increase volume", null),
        QuickAction("Screenshot", Icons.Outlined.Screenshot, "Take a screenshot", null),
        QuickAction("Alarm", Icons.Outlined.Alarm, null, "Set an alarm for "),
        QuickAction("Web Search", Icons.Outlined.Search, null, "Search the web for "),
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text(
                    text = "PhonePilot AI",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "Your phone, on your terms.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(
                onClick = onSettings,
                modifier = Modifier.semantics { contentDescription = "Open settings" },
            ) {
                Icon(Icons.Outlined.Settings, contentDescription = null)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(28.dp),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "How can I help?",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                )
                Text(
                    text = "Speak naturally. PhonePilot checks every action before it changes your phone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(top = 6.dp),
                )
                Spacer(Modifier.height(18.dp))
                Surface(
                    modifier = Modifier
                        .size(104.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onSpeak)
                        .semantics { contentDescription = "Start voice input" },
                    color = MaterialTheme.colorScheme.primary,
                    shape = CircleShape,
                    shadowElevation = 6.dp,
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Outlined.Mic,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(42.dp),
                        )
                    }
                }
                Text(
                    text = "Tap to speak",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.padding(top = 10.dp),
                )
                AnimatedVisibility(state.lastRecognizedCommand != null) {
                    Text(
                        text = "Heard: “${state.lastRecognizedCommand.orEmpty()}”",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = commandText,
                onValueChange = onCommandTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text("Type a command…") },
                singleLine = true,
                shape = RoundedCornerShape(18.dp),
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = onSubmit,
                enabled = commandText.isNotBlank(),
                modifier = Modifier
                    .size(54.dp)
                    .background(
                        color = if (commandText.isNotBlank()) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        },
                        shape = CircleShape,
                    )
                    .semantics { contentDescription = "Send command" },
            ) {
                Icon(
                    Icons.Outlined.Send,
                    contentDescription = null,
                    tint = if (commandText.isNotBlank()) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }
        }

        SectionTitle("Quick Actions")
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            quickActions.chunked(2).forEach { rowActions ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    rowActions.forEach { action ->
                        QuickActionCard(
                            action = action,
                            onClick = { onQuickAction(action.command ?: "", action.prefill) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                    if (rowActions.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            SectionTitle("Recent Commands")
            if (state.history.isNotEmpty()) {
                TextButton(onClick = onClearHistory) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Clear")
                }
            }
        }
        if (state.history.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                ),
            ) {
                Text(
                    text = "Your completed commands will appear here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(18.dp),
                )
            }
        } else {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column {
                    state.history.take(8).forEachIndexed { index, entry ->
                        HistoryRow(entry)
                        if (index < state.history.take(8).lastIndex) Divider()
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

private data class QuickAction(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val command: String?,
    val prefill: String?,
)

@Composable
private fun QuickActionCard(
    action: QuickAction,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .height(68.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Surface(
                color = MaterialTheme.colorScheme.secondaryContainer,
                shape = CircleShape,
                modifier = Modifier.size(34.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        action.icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                        modifier = Modifier.size(19.dp),
                    )
                }
            }
            Text(
                text = action.label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun HistoryRow(entry: HistoryEntry) {
    val (icon, tint, label) = when (entry.status) {
        HistoryStatus.SUCCESS -> Triple(Icons.Outlined.CheckCircle, Color(0xFF268653), "Succeeded")
        HistoryStatus.FAILED -> Triple(Icons.Outlined.ErrorOutline, Color(0xFFB3261E), "Failed")
        HistoryStatus.CANCELLED -> Triple(Icons.Outlined.Cancel, Color(0xFF8A5A00), "Cancelled")
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
        Text(
            text = entry.command,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
        )
    }
}

@Composable
private fun SettingsScreen(
    onBack: () -> Unit,
    onPermissions: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader("Settings", onBack)
        SettingsCard(
            icon = Icons.Outlined.Security,
            title = "Permissions",
            subtitle = "Review why PhonePilot asks for access and manage it in Android settings.",
            onClick = onPermissions,
        )
        SettingsCard(
            icon = Icons.Outlined.RecordVoiceOver,
            title = "Voice settings",
            subtitle = "Uses Android's system speech recognizer and the phone's current language. No recording runs in the background.",
        )
        SettingsCard(
            icon = Icons.Outlined.Shield,
            title = "Safety confirmations",
            subtitle = "Always on. Calls and alarms require a final confirmation. PhonePilot never sends messages or performs hidden actions in V1.",
        )
        SettingsCard(
            icon = Icons.Outlined.Info,
            title = "About PhonePilot AI",
            subtitle = "Version 1.0 • Local command parser • Built for your own Android phone.",
        )
    }
}

@Composable
private fun PermissionsScreen(
    refreshKey: Int,
    onBack: () -> Unit,
    onRequest: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val permissions = listOf(
        PermissionInfo(
            Manifest.permission.RECORD_AUDIO,
            "Microphone",
            "Converts a spoken command into text only after you tap Speak.",
        ),
        PermissionInfo(
            Manifest.permission.READ_CONTACTS,
            "Contacts",
            "Finds the phone number for a contact you named before showing a call confirmation.",
        ),
        PermissionInfo(
            Manifest.permission.CALL_PHONE,
            "Phone calls",
            "Places a call only after you confirm the contact and number.",
        ),
        PermissionInfo(
            Manifest.permission.CAMERA,
            "Camera / flashlight",
            "Controls the hardware flashlight through Android's camera API. PhonePilot does not take photos.",
        ),
    )
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        ScreenHeader("Permissions", onBack)
        Text(
            text = "Only request a permission when the feature needs it. You can also manage these choices from Android Settings.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        permissions.forEach { info ->
            val granted = ContextCompat.checkSelfPermission(context, info.permission) ==
                PackageManager.PERMISSION_GRANTED
            PermissionCard(
                info = info,
                granted = granted,
                onRequest = { onRequest(info.permission) },
            )
        }
        Text(
            text = "Not requested in V1: internet, location, SMS, accessibility, notification, or background microphone permissions.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp),
        )
        @Suppress("UNUSED_VARIABLE")
        val keepRefreshKey = refreshKey
    }
}

private data class PermissionInfo(
    val permission: String,
    val title: String,
    val explanation: String,
)

@Composable
private fun PermissionCard(
    info: PermissionInfo,
    granted: Boolean,
    onRequest: () -> Unit,
) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text(
                    text = if (granted) "Allowed" else "Not allowed",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (granted) Color(0xFF268653) else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text(info.explanation, style = MaterialTheme.typography.bodyMedium)
            if (!granted) {
                OutlinedButton(onClick = onRequest) {
                    Text("Allow when needed")
                }
            }
        }
    }
}

@Composable
private fun SettingsCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: (() -> Unit)? = null,
) {
    Card(
        modifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier,
    ) {
        Row(
            modifier = Modifier.padding(18.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "Back")
        }
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ConfirmationDialog(
    confirmation: Confirmation,
    onConfirm: () -> Unit,
    onCancel: () -> Unit,
) {
    when (confirmation) {
        is Confirmation.Call -> AlertDialog(
            onDismissRequest = onCancel,
            title = { Text("Confirm call") },
            text = { Text("Call ${confirmation.contactName} at ${confirmation.phoneNumber}?") },
            dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
            confirmButton = { Button(onClick = onConfirm) { Text("Call") } },
        )
        is Confirmation.Alarm -> AlertDialog(
            onDismissRequest = onCancel,
            title = { Text("Confirm alarm") },
            text = {
                Text(
                    "Set an alarm for ${confirmation.spec.displayTime()} " +
                        (if (confirmation.spec.tomorrowRequested) {
                            "tomorrow?"
                        } else {
                            "on the next matching time?"
                        }),
                )
            },
            dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
            confirmButton = { Button(onClick = onConfirm) { Text("Set alarm") } },
        )
    }
}

private fun speechIntent(): Intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a PhonePilot command")
}