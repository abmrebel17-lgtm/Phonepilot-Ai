package com.phonepilot.ai.engine

import com.phonepilot.ai.model.CommandIntent
import com.phonepilot.ai.model.VolumeOperation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val parser = LocalCommandParser()

    @Test
    fun understandsNaturalOpenAppVariants() {
        listOf("Open YouTube", "Can you open YouTube?", "Launch YouTube for me").forEach { input ->
            val result = parser.parse(input)
            assertTrue(result is ParseResult.Parsed)
            assertEquals(CommandIntent.OPEN_APP, (result as ParseResult.Parsed).command.intent)
            assertEquals("youtube", result.command.target)
        }
    }

    @Test
    fun understandsCallAndSearch() {
        val call = parser.parse("Could you call Mom")
        val search = parser.parse("Search the web for weather in Srinagar")

        assertEquals(CommandIntent.CALL, (call as ParseResult.Parsed).command.intent)
        assertEquals("mom", call.command.target)
        assertEquals(CommandIntent.WEB_SEARCH, (search as ParseResult.Parsed).command.intent)
        assertEquals("weather in srinagar", search.command.searchQuery)
    }

    @Test
    fun understandsDeviceActions() {
        val flashlight = parser.parse("Please turn off the torch") as ParseResult.Parsed
        val volume = parser.parse("Set volume to 50 percent") as ParseResult.Parsed
        val screenshot = parser.parse("Take a screen shot") as ParseResult.Parsed

        assertEquals(CommandIntent.FLASHLIGHT, flashlight.command.intent)
        assertEquals(false, flashlight.command.flashlightOn)
        assertEquals(CommandIntent.VOLUME, volume.command.intent)
        assertEquals(VolumeOperation.SET, volume.command.volumeOperation)
        assertEquals(50, volume.command.volumePercent)
        assertEquals(CommandIntent.SCREENSHOT, screenshot.command.intent)
    }

    @Test
    fun parsesAlarmTimeAndTomorrow() {
        val result = parser.parse("Set an alarm for 7:05 AM tomorrow") as ParseResult.Parsed

        assertEquals(CommandIntent.ALARM, result.command.intent)
        assertEquals(7, result.command.alarm?.hour)
        assertEquals(5, result.command.alarm?.minute)
        assertEquals(true, result.command.alarm?.tomorrowRequested)
    }

    @Test
    fun rejectsUnknownCommandClearly() {
        val result = parser.parse("Read my private messages")

        assertTrue(result is ParseResult.Unknown)
    }
}